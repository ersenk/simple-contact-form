<?php

return [
    'site_title' => 'Londonist Contact Form',

];
