<?php

return [
    'previous' => '« Önceki',
    'next'     => 'Sonraki »',

];
