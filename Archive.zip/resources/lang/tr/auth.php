<?php

return [
    'failed'   => 'Bilgiler kayıtlarımızla uyuşmuyor.',
    'password' => 'Sağlanan şifre yanlış.',
    'throttle' => 'Çok fazla hatalı giriş denemesi yaptınız. Lütfen :seconds sonra tekrar deneyin',

];
