<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.contact.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.contacts.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="responsible_user_id"><?php echo e(trans('cruds.contact.fields.responsible_user')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('responsible_user') ? 'is-invalid' : ''); ?>" name="responsible_user_id" id="responsible_user_id">
                    <?php $__currentLoopData = $responsible_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('responsible_user_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('responsible_user')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('responsible_user')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.contact.fields.responsible_user_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="first_name"><?php echo e(trans('cruds.contact.fields.first_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('first_name') ? 'is-invalid' : ''); ?>" type="text" name="first_name" id="first_name" value="<?php echo e(old('first_name', '')); ?>" required>
                <?php if($errors->has('first_name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('first_name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.contact.fields.first_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="last_name"><?php echo e(trans('cruds.contact.fields.last_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('last_name') ? 'is-invalid' : ''); ?>" type="text" name="last_name" id="last_name" value="<?php echo e(old('last_name', '')); ?>" required>
                <?php if($errors->has('last_name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('last_name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.contact.fields.last_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="country_id"><?php echo e(trans('cruds.contact.fields.country')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('country') ? 'is-invalid' : ''); ?>" name="country_id" id="country_id">
                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('country_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('country')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('country')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.contact.fields.country_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="phone"><?php echo e(trans('cruds.contact.fields.phone')); ?></label>
                <input class="form-control <?php echo e($errors->has('phone') ? 'is-invalid' : ''); ?>" type="text" name="phone" id="phone" value="<?php echo e(old('phone', '')); ?>" required>
                <?php if($errors->has('phone')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('phone')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.contact.fields.phone_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="meeting_date"><?php echo e(trans('cruds.contact.fields.meeting_date')); ?></label>
                <input class="form-control datetime <?php echo e($errors->has('meeting_date') ? 'is-invalid' : ''); ?>" type="text" name="meeting_date" id="meeting_date" value="<?php echo e(old('meeting_date')); ?>" required>
                <?php if($errors->has('meeting_date')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('meeting_date')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.contact.fields.meeting_date_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required"><?php echo e(trans('cruds.contact.fields.budget')); ?></label>
                <select class="form-control <?php echo e($errors->has('budget') ? 'is-invalid' : ''); ?>" name="budget" id="budget" required>
                    <option value disabled <?php echo e(old('budget', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\Contact::BUDGET_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('budget', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('budget')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('budget')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.contact.fields.budget_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required"><?php echo e(trans('cruds.contact.fields.number_of_bedrooms')); ?></label>
                <select class="form-control <?php echo e($errors->has('number_of_bedrooms') ? 'is-invalid' : ''); ?>" name="number_of_bedrooms" id="number_of_bedrooms" required>
                    <option value disabled <?php echo e(old('number_of_bedrooms', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\Contact::NUMBER_OF_BEDROOMS_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('number_of_bedrooms', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('number_of_bedrooms')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('number_of_bedrooms')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.contact.fields.number_of_bedrooms_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="team_id"><?php echo e(trans('cruds.contact.fields.team')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('team') ? 'is-invalid' : ''); ?>" name="team_id" id="team_id">
                    <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('team_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('team')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('team')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.contact.fields.team_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ersen/Web/londonist-contact-form/resources/views/admin/contacts/create.blade.php ENDPATH**/ ?>