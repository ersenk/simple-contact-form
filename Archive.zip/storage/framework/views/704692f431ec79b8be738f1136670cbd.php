[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /Users/ersen/Web/londonist-contact-form/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>