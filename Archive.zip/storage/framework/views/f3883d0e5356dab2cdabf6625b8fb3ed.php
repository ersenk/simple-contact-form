<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.sendEmail.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.send-emails.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="user_id"><?php echo e(trans('cruds.sendEmail.fields.user')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('user') ? 'is-invalid' : ''); ?>" name="user_id" id="user_id">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('user_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('user')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('user')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.sendEmail.fields.user_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="contact_id"><?php echo e(trans('cruds.sendEmail.fields.contact')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('contact') ? 'is-invalid' : ''); ?>" name="contact_id" id="contact_id">
                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('contact_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('contact')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('contact')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.sendEmail.fields.contact_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="email_template_id"><?php echo e(trans('cruds.sendEmail.fields.email_template')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('email_template') ? 'is-invalid' : ''); ?>" name="email_template_id" id="email_template_id" required>
                    <?php $__currentLoopData = $email_templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('email_template_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('email_template')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('email_template')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.sendEmail.fields.email_template_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="body"><?php echo e(trans('cruds.sendEmail.fields.body')); ?></label>
                <textarea class="form-control <?php echo e($errors->has('body') ? 'is-invalid' : ''); ?>" name="body" id="body"><?php echo e(old('body')); ?></textarea>
                <?php if($errors->has('body')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('body')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.sendEmail.fields.body_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ersen/Web/londonist-contact-form/resources/views/admin/sendEmails/create.blade.php ENDPATH**/ ?>