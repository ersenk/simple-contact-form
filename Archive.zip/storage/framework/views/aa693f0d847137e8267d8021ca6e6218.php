<?php echo e($slot); ?>

<?php /**PATH /Users/ersen/Web/londonist-contact-form/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>