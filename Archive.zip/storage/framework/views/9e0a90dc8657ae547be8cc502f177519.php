<?php echo e($slot); ?>

<?php /**PATH /Users/ersen/Web/londonist-contact-form/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>